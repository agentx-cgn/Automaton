

export interface IPrettyPrint {
    prettyPrint(): string;
}